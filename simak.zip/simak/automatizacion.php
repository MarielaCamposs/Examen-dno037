<!DOCTYPE html>
	<html lang="es">
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Simak</title>
	<link rel="icon" type="image/png" href="img/icono.png" />
	<!-- Search Engine -->
	<meta name="description" content="Somos una empresa especializada en productos para la conducción y control de fluidos, dentro de las áreas industriales, químicas, mineras y sanitarias. Poseemos área de ventas como de servicios de reparación.">
	<!-- Schema.org for Google -->
	<meta itemprop="name" content="Simak">
	<meta itemprop="description" content="Somos una empresa especializada en productos para la conducción y control de fluidos, dentro de las áreas industriales, químicas, mineras y sanitarias. Poseemos área de ventas como de servicios de reparación">
	<!-- Twitter -->
	<meta name="twitter:card" content="summary">
	<meta name="twitter:title" content="Simak">
	<meta name="twitter:description" content="Somos una empresa especializada en productos para la conducción y control de fluidos, dentro de las áreas industriales, químicas, mineras y sanitarias. Poseemos área de ventas como de servicios de reparación.">
	<!-- Open Graph general (Facebook, Pinterest & Google+) -->
	<meta name="og:title" content="Simak">
	<meta name="og:description" content="Somos una empresa especializada en productos para la conducción y control de fluidos, dentro de las áreas industriales, químicas, mineras y sanitarias. Poseemos área de ventas como de servicios de reparación">
	<meta name="og:image" content="www.simak.cl/logo.jpg">
	<meta name="og:url" content="www.simak.cl">
	<meta name="og:site_name" content="Simak limitada">
	<meta name="og:type" content="website">

<!-- css -->
<link href="css/bootstrap.min.css" rel="stylesheet" />
<link href="css/cubeportfolio.min.css" rel="stylesheet" />
<link href="css/style.css" rel="stylesheet" />
<!-- js -->
<script src="js/jquery.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="plugins/flexslider/jquery.flexslider-min.js"></script>
<script src="plugins/flexslider/flexslider.config.js"></script>
<script src="js/jquery.appear.js"></script>
<script src="js/stellar.js"></script>
<script src="js/classie.js"></script>
<script src="js/uisearch.js"></script>
<script src="js/jquery.cubeportfolio.min.js"></script>
<script src="js/google-code-prettify/prettify.js"></script>
<script src="js/animate.js"></script>
<script src="js/custom.js"></script>

<!-- Theme skin -->
<link id="t-colors" href="skins/default.css" rel="stylesheet" />

</head>

<body>

<div id="wrapper">
	<!-- start header -->
	<header>
				 <?php include('header.php');?>
	</header>
	<!-- end header -->

	<div class="text-center">
	<h3>Automatización de válvulas</h3>
	<section id="content">
	<div class="container">

		<div class="item">
				<div class="col-lg-6">
					<h4>Actuadores Neumáticos</h4>
					<img src="img/automatizacion/neumaticos.jpg" alt="Actuador neumatico" class="img-responsive pull-left" />
					<p>Para operación de 1/4 de vuelta o de desplazamiento lineal., servicios On-Off o control proporcional. Disponibles para comunicación de red de campo del tipo Fielbus Fundation, Profibus ,Modbus y Hart. </p>
				</div>
				</div>

		 <div class="item">
				<div class="col-lg-6">
					<h4>Actuadores Eléctricos</h4>
					<img src="img/automatizacion/electrico.jpg" alt="Actuadores Eléctricos" class="img-responsive pull-left" />
					<p> Para operación multivuelta y  1/4 de vuelta,  servicios On-Off o proporcional. Disponibles para comunicación de red de campo del tipo Fielbus Fundation, Profibus , Modbus y Hart.</p>
				</div>
				</div>
			</div>

			<br>
			<br>
<hr>
			<div class="container">
				<h3>Protocolos de comunicación</h3>
				<br>
<img src="img/automatizacion/protocolo.JPG" alt="Protocolo de comunicación">
						<br>
	<p>* Para consultas acerca de otros productos, disponibilidad o precios, comunicarse directamente a nuestro correos o teléfonos</p>
						<br>
						<br>
						<br>
						<br>
						<br>
					</div>
 </div>

					<footer>
						 <?php include('footer.php');?>
					</footer>

			 <a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>

			 </body>
			 </html>
