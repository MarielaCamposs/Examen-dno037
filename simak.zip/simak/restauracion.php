<!DOCTYPE html>
	<html lang="es">
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Simak</title>
	<link rel="icon" type="image/png" href="img/icono.png" />
	<!-- Search Engine -->
	<meta name="description" content="Somos una empresa especializada en productos para la conducción y control de fluidos, dentro de las áreas industriales, químicas, mineras y sanitarias. Poseemos área de ventas como de servicios de reparación.">
	<!-- Schema.org for Google -->
	<meta itemprop="name" content="Simak">
	<meta itemprop="description" content="Somos una empresa especializada en productos para la conducción y control de fluidos, dentro de las áreas industriales, químicas, mineras y sanitarias. Poseemos área de ventas como de servicios de reparación">
	<!-- Twitter -->
	<meta name="twitter:card" content="summary">
	<meta name="twitter:title" content="Simak">
	<meta name="twitter:description" content="Somos una empresa especializada en productos para la conducción y control de fluidos, dentro de las áreas industriales, químicas, mineras y sanitarias. Poseemos área de ventas como de servicios de reparación.">
	<!-- Open Graph general (Facebook, Pinterest & Google+) -->
	<meta name="og:title" content="Simak">
	<meta name="og:description" content="Somos una empresa especializada en productos para la conducción y control de fluidos, dentro de las áreas industriales, químicas, mineras y sanitarias. Poseemos área de ventas como de servicios de reparación">
	<meta name="og:image" content="www.simak.cl/logo.jpg">
	<meta name="og:url" content="www.simak.cl">
	<meta name="og:site_name" content="Simak limitada">
	<meta name="og:type" content="website">
<!-- css -->
<link href="css/bootstrap.min.css" rel="stylesheet" />
<link href="plugins/flexslider/flexslider.css" rel="stylesheet" media="screen" />
<link href="css/cubeportfolio.min.css" rel="stylesheet" />
<link href="css/style.css" rel="stylesheet" />
<!-- js -->
<script src="js/jquery.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="plugins/flexslider/jquery.flexslider-min.js"></script>
<script src="plugins/flexslider/flexslider.config.js"></script>
<script src="js/jquery.appear.js"></script>
<script src="js/stellar.js"></script>
<script src="js/classie.js"></script>
<script src="js/uisearch.js"></script>
<script src="js/jquery.cubeportfolio.min.js"></script>
<script src="js/google-code-prettify/prettify.js"></script>
<script src="js/animate.js"></script>
<script src="js/custom.js"></script>

<!-- Theme skin -->
<link id="t-colors" href="skins/default.css" rel="stylesheet" />

<!-- ====================== -->

</head>
<body>


	<!-- start header -->
	<header>
				 <?php include('header.php');?>
	</header>
	<!-- end header -->
<div class="text-center">
<h3>Recuperación y mantención de Equipos industriales </h3>
				<article>
					<div class="container">
						<div class="post-slider">
							<div class="post-heading">
								<p>Simak  desarrolla dentro de sus líneas de trabajo la recuperación y mantención de válvulas y equipos industriales, tantos para equipos suministrados por nuestra empresa como  a equipos propios de cada cliente. Este servicio permite una optima disponibilidad  de sus sistemas considerando  también un menor costo  operativo.  </p>
                <br>

							</div>
							<!-- start flexslider -->
							<p>Antes / Después</p>
							<div id="post-slider" class="postslider flexslider">
								<ul class="slides">
									<li>
									<img src="img/servicios/1.jpg" alt="Antes" />
									</li>
									<li>
									<img src="img/servicios/2.jpg" alt="Despues" />
									</li>
								</ul>
							</div>
							</div>
						</div>
</div>

<br>
<div class="text-center">
	<h3>Ventajas</h3>
</div>
<br>
<article class="container"
 <article class="row">
<div class="col-lg-6">
			 <dl class="dl-horizontal">
				 <dd>Entre las ventajas mas importantes de la recuperación podemos nombrar:</dd>
				 <dt>Costo</dt>
				 <dd>-Costo de recuperación no sobrepasa el 40% del costo de una válvula nueva.</dd>
				 	 <dt>Garantia</dt>
				 <dd>-El trabajo de recuperación esta garantizado.</dd>
				 <dt>Tiempo</dt>
				 <dd>-El tiempo requerido en recuperar  el equipo es menor que el tiempo de fabricación del mismo. </dd>
				 	 <dt>Informe técnico</dt>
				 <dd>-El equipo recuperado cuenta con un informe técnico de las actividades realizadas, certificaciones de los
   materiales utilizados como de las pruebas a que fueron sometidos.</dd>
			 </dl>
			 </div>
			 <div class="col-lg-3">
				 <img src="img/taller.JPG" width="430px" alt="Taller"
		 </div>
</article>
</article>

<div class="container">
		<div class="text-center">Antes / Después</div>
<div id="post-slider" class="postslider flexslider">
	<ul class="slides">
		<li>
		<img src="img/servicios/3.jpg" alt="Antes" />
		</li>
		<li>
		<img src="img/servicios/4.jpg" alt="Despues" />
		</li>
	</ul>
</div>
</div>

<div class="container"
		 <div class="col-sm-4">
					 <h3>Etapas generales del servicio de recuperación</h3>
					 <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">

						 <div class="panel panel-default">
							 <div class="panel-heading" role="tab" id="headingOne">
								 <h4 class="panel-title">
									 <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
										 <p>Proceso de evaluación</p>
									 </a>
								 </h4>
							 </div>
							 <div id="collapseOne" class="panel-collapse collapse " role="tabpanel" aria-labelledby="headingOne">
								 <div class="panel-body">
								<p>	 El proceso de evaluación posee las siguientes etapas: <br>- Recepción del  Equipo <br>- Evaluación general  <br>- Emisión del informe técnico del estado del equipo <br> - Emisión de oferta técnico económica por la recuperación del equipo </p>
								 </div>
							 </div>
						 </div>
              </div>

						 <div class="panel panel-default">
							 <div class="panel-heading" role="tab" id="headingTwo">
								 <h4 class="panel-title">
									 <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
										 <p>Informe técnico económico</p>
									 </a>
								 </h4>
							 </div>
							 <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
								 <div class="panel-body">
									<p> El informe técnico económico  por la recuperación de una válvula, a modo de <u>ejemplo</u>, posee el siguiente esquema: <br>- Descripción del equipo: Válvula de Cuchillo Pasante tamaño XX” marca XXX modelo XXX; cuerpo en hierro dúctil, cuchillo de acero  inoxidable, asientos manguitos  en caucho.  Accionamiento por
	                cilindro Hidráulico.<br>- Actividades a realizar:  Normalizar cuerpo zona alojamientos de los sellos principales, normalizar guías laterales y caja superior. Reparar y reconstruir por aporte y soldadura cuerpo principal  zona lateral y zona adyacente a la caja  estopa,  dado el deterioro por efecto de la abrasión y ruptura existente, y la normalización del bonete superior.  Fabricar sellos manguitos 2 unidades, recambiables moldeados en Caucho
	                anti-abrasivo NBR, reparar y rectificar cuchilla eliminando deterioro existente.  Normalizar y habilitar soportes laterales de fijación del accionamiento.  Mantención general al cilindro hidraulico de doble efecto con el cambio de la totalidad de sellos, tanto de eje como de pistón.  Terminción final de partes expuestas según requerimiento.<br>- Armado y reglaje general<br>- Pruebas hidrostáticas<br>- Despacho </p>

                 </div>
							 </div>
						 </div>
					 </div>
	        </div>
					<br>
					<br>
					<div class="container"
				 <p>* Para consultas o evaluaciones, comunicarse directamente a nuestro correo o teléfono de contacto</p>
</div>
					<br>
					<br>


<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>

<footer>
	 <?php include('footer.php');?>
</footer>

</body>
</html>
