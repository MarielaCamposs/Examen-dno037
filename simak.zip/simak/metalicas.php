<!DOCTYPE html>
	<html lang="es">
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Simak</title>
	<link rel="icon" type="image/png" href="img/icono.png" />
	<!-- Search Engine -->
	<meta name="description" content="Somos una empresa especializada en productos para la conducción y control de fluidos, dentro de las áreas industriales, químicas, mineras y sanitarias. Poseemos área de ventas como de servicios de reparación.">
	<!-- Schema.org for Google -->
	<meta itemprop="name" content="Simak">
	<meta itemprop="description" content="Somos una empresa especializada en productos para la conducción y control de fluidos, dentro de las áreas industriales, químicas, mineras y sanitarias. Poseemos área de ventas como de servicios de reparación">
	<!-- Twitter -->
	<meta name="twitter:card" content="summary">
	<meta name="twitter:title" content="Simak">
	<meta name="twitter:description" content="Somos una empresa especializada en productos para la conducción y control de fluidos, dentro de las áreas industriales, químicas, mineras y sanitarias. Poseemos área de ventas como de servicios de reparación.">
	<!-- Open Graph general (Facebook, Pinterest & Google+) -->
	<meta name="og:title" content="Simak">
	<meta name="og:description" content="Somos una empresa especializada en productos para la conducción y control de fluidos, dentro de las áreas industriales, químicas, mineras y sanitarias. Poseemos área de ventas como de servicios de reparación">
	<meta name="og:image" content="www.simak.cl/logo.jpg">
	<meta name="og:url" content="www.simak.cl">
	<meta name="og:site_name" content="Simak limitada">
	<meta name="og:type" content="website">
<!-- css -->
<link href="css/bootstrap.min.css" rel="stylesheet" />
<link href="css/cubeportfolio.min.css" rel="stylesheet" />
<link href="css/style.css" rel="stylesheet" />
<!-- js -->
<script src="js/jquery.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.appear.js"></script>
<script src="js/stellar.js"></script>
<script src="js/classie.js"></script>
<script src="js/uisearch.js"></script>
<script src="js/jquery.cubeportfolio.min.js"></script>
<script src="js/google-code-prettify/prettify.js"></script>
<script src="js/animate.js"></script>
<script src="js/custom.js"></script>


<!-- Theme skin -->
<link id="t-colors" href="skins/default.css" rel="stylesheet" />

</head>
<body>
<div id="wrapper">
	<!-- start header -->
	<header>
				 <?php include('header.php');?>
	</header>
	<!-- end header -->

	<div class="text-center">
	<h3>Válvulas Metalicas</h3>
	<section id="content">
	<div class="container">


		<div class="item">
				<div class="col-md-4">
					<h4>Válvulas de Guillotina</h4>
					<img src="img/metalicas/GUILLOTINA.jpg" alt="Guillotina" class="img-responsive pull-left" />
           <div align="justify">-Presión de trabajo hasta 1000 PSI CWP.<br>- Diseño unidireccional o bidireccional. <br>-Cuerpo monoblock  con cárter inferior o sellado, fabricado en hierro nodular, acero carbono, aleaciones inoxidables, todos con prensa estopa superior. <br>- Guillotina fabricada en acero inoxidable, aleaciones especiales o con revestimientos de alta dureza. <br>-Asientos elastoméricos recambiables. <br>-Conexión semi Lug o Lug. <br>-Operación manual o automatizada. <br>-Dimensiones desde 2” hasta 60” (50mm hasta 1500mm).</div>
				</div>
				</div>

				<div class="item">
						<div class="col-md-4">
							<h4>Válvula de Globo</h4>
							<img src="img/metalicas/GLOBO.jpg" alt="Válvula de Globo" class="img-responsive pull-left" />
							  <div align="justify">-Clase ASME 150/300/600/900/1500/2500. <br>-Bonete apernado.<br>- Cuerpo y bonete en acero carbono o aleaciones inoxidables, disco de cierre tipo recto o cónico para regulación. <br>-Extremos flangeados o soldables.<br>- Operación manual o automatizada.<br>- Tamaño desde 1” a  24” (50mm hasta 600mm).</div>
						</div>
						</div>

						<div class="item">
								<div class="col-md-4">
									<h4>Válvula de control hidráulica</h4>
									<img src="img/metalicas/hidraulica.jpg" alt="control hidráulica" class="img-responsive pull-left" />
									  <div align="justify">- PN-10 hasta PN-64.<br>- Cuerpo fabricado en hierro dúctil o acero al carbono revestidos con Rilsan, también aleaciones inoxidables. <br>-Pilotos en bronce o aceros inoxidables. <br>-Diafragma fabricado en caucho natural y otros elastómeros.<br>- Extremos roscado o bridados.<br>- Operación automática. <br>-Funciones On-Off, regulación de presión, regulación de flujo, control de nivel, anticipadora de ondas y alivio entre otras.<br>- Tamaño 1” hasta 16” (25mm hasta 400mm).</div>
								</div>
								</div>
          </div>

								<section id="content">
										<div class="container">
										<div class="item">
										<div class="col-md-4">
											<h4>Válvula Pinch</h4>
											<img src="img/metalicas/pinch.jpg" alt="Válvula Pinch" class="img-responsive pull-left" />
											  <div align="justify"> -Cuerpo cerrado o abierto.<br>- Presión de trabajo hasta 400 PSI. <br>-Cuerpo fabricado en hierro nodular o acero carbono, manga reforzada fabricada en elastómeros de alta resistencia al desgaste.<br>-Extremos bridados. <br>-Operación manual o automatizada. <br>-Tamaños desde 2” hasta 36”.</div>
										</div>
										</div>

										<div class="item">
												<div class="col-md-4">
													<h4>Válvula de Mariposa </h4>
													<img src="img/metalicas/mariposa1.jpg" alt="Válvula de Mariposa" class="img-responsive pull-left" />
													  <div align="justify">- Eje excéntrico, Clase ANSI 150/300/600. <br>-Cuerpo y disco fabricado en acero carbono, aceros inoxidables y materiales especiales.<br>- Asiento metálico o termostático.<br>- Extremos tipo Wafer, semi Lug, Lug o flangeados. <br>-Operación Manual o automatizada. <br>-Tamaños desde 2” hasta 48” (50mm hasta 1200mm).</div>
												</div>
												</div>

												<div class="item">
														<div class="col-md-4">
															<h4>Válvula de Retención </h4>
															<img src="img/metalicas/retencion.jpg" alt="Válvula de Retención" class="img-responsive pull-left" />
																  <div align="justify">- Diseño según API 600<br>-Clase ASME 150/300/600/900/1500/2500<br>-Tapa apernada Cuerpo y disco de cierre en acero carbono o aleaciones inoxidables.<br>-Trim según API 600. <br>-Extremos flangeados o soldables. <br>-Operación manual o automatizada. <br>-Tamaño desde1” a  60” (25mm hasta 1500mm).</div>
														</div>
														</div>
                </div>

														<section id="content">
																<div class="container">

														<div class="item">
																<div class="col-md-4">
																	<h4>Válvula de Bola</h4>
																	<img src="img/metalicas/BOLA1.jpg" alt="Válvula de Bola" class="img-responsive pull-left" />
																	  <div align="justify">-Tipo flotante o bola tipo Trunnion (Guiada). <br>-Clase ASME 150/300/600/900/1500/2500. <br>-Aptas para servicio de alta temperatura, normal y criogénica. <br>-Cuerpo y bola en acero al carbono o aleaciones inoxidables, asientos termoplásticos o metálicos. <br>-Operación manual o automatizada. <br>-Tamaños desde 1/2” hasta 60” (15mm a 1500mm).</div>
																</div>
																</div>

																<div class="item">
																		<div class="col-md-4">
																			<h4>Válvula de compuerta</h4>
																			<img src="img/metalicas/COMPUERTA.jpg" alt="Válvula de compuerta" class="img-responsive pull-left" />
																			  <div align="justify">-Diseño según API 600, Clase ASME 150/300/600/900/1500/2500.  <br>-Bonete apernado. <br>-Cuerpo y bonete en acero carbono o aleaciones inoxidables, cuña flexible. <br>-Trim según API 600. <br>-Extremos flangeados o soldables. <br>-Operación manual o automatizada. <br>-Tamaño desde 1” a  64”</div>
																		</div>
																		</div>

																		<div class="item">
																				<div class="col-md-4">
																					<h4>Válvula de Diafragma </h4>
																					<img src="img/metalicas/DIAFRAGMA.jpg" alt="Válvula de Diafragma" class="img-responsive pull-left" />
																					  <div align="justify"> -PN-16, Paso recto o paso vertedero. <br>-Cuerpo en Hierro fundido, Hierro Nodular, Acero inoxidable, sin revestimiento o revestidos en polímeros o elastómeros. <br>-Diafragma elastoméricos o revestidos en polímeros. <br>-Conexión roscada, bridada, soldar y tipo clamp. <br>-Operación manual o automatizada. <br>-Dimensiones desde 1/4”a 14” (8mm a 350mm).</div>
																				</div>
																				</div>
	                                 </div>
	<section id="content">
			<div class="container">
		<div class="item">
						<div class="col-md-4">
							<h4>Válvula de Mariposa</h4>
							<img src="img/metalicas/MARIPOSA2.jpg" alt="Válvula de Mariposa" class="img-responsive pull-left" />
							  <div align="justify">-Eje centrado, PN-16. <br>-Cuerpo fabricado en hierro dúctil,  disco fabricado en hierro dúctil o acero inoxidable, revestido en termoplásticos o elastómeros. <br>-Asiento elastomérico. <br>-Extremos tipo Wafer, semi Lug ,Lug o flangeados. <br>-Operación Manual o automatizada. <br>-Tamaños desde 2” hasta 48” (50mm a 1200mm).</div>
						</div>
						</div>

						<div class="item">
								<div class="col-md-4">
									<h4>Válvula de Retención</h4>
									<img src="img/metalicas/retencion2.jpg" alt="Válvula de Retención" class="img-responsive pull-left" />
									  <div align="justify">-PN-16 con visor de línea.<br>-Tapa apernada, Cuerpo  en hierro dúctil revestido en PTFE o PFA, Bola de cierre en PTFE sólido.  <br>-Extremos flangeados. <br>-Tamaño desde 1/2” a  8” (15mm hasta 200mm).</div>
								</div>
							</div>

										<div class="item">
												<div class="col-md-4">
													<h4>Válvula de Bola </h4>
													<img src="img/metalicas/bola2.jpg" alt="Válvula de Bola " class="img-responsive pull-right" />
													  <div align="justify">-Tipo flotante PN16. <br>-Cuerpo y bola en acero al carbono o aleaciones inoxidables revestidas en PTFE o PFA, asientos termoplásticos en PTFE o PFA. <br>- Operación manual o automatizada. <br>-Tamaños desde 1/2” hasta 6” (15mm a 150mm)</div>
												</div>
												</div>
	</div>

	<br>
	<br>
	<p> * Para consultas acerca de otros productos, disponibilidad o precios, comunicarse directamente a nuestro correos o teléfonos</p>
	<br>

</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>

<footer>
	 <?php include('footer.php');?>
</footer>

</body>
</html>
