<div class="container">

    <article class="row">
             <div class="col-sm-9">
               <p> Simak Ltda <br> <i class="fa fa-home fa-fw"></i>    Vasco de gama 5488, Ñuñoa, Santiago - Chile   <i class="fa fa-phone"></i>  Tel (+56-9) 5 829 0904 - (+56-2) 2 226 2526   <i class="fa fa-envelope-o fa-fw"></i>Email  info@simak.cl</p> </div>
                <div class="col-sm-3">
                <img src="img/logotipo.png" alt="Logo Simak"width=250 class="img-responsive">
              </div>
           </article>

</footer>
