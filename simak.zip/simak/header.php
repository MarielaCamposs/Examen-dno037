<header>
    <div class="top">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <ul class="topleft-info">
              <li><i class="fa fa-phone"></i> Tel (+56-2) 2 226 2526 - (+56-9) 5 829 0904  </li>
            </ul>
          </div>

        </div>
      </div>
    </div>

      <div class="navbar navbar-default navbar-static-top">
          <div class="container">
              <div class="navbar-header">
                  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                  </button>
                  <a class="navbar-brand" href="logo.html"><img src="img/logotipo.png" alt="Logo Simak" width="130" /></a>
              </div>
              <div class="navbar-collapse collapse ">
                  <ul class="nav navbar-nav">
                      <li class="dropdown active">
          </li>
          <li><a href="index.php">Sobre nosotros</a></li>
                      <li class="dropdown">
                          <a href="#" class="dropdown-toggle " data-toggle="dropdown" data-hover="dropdown" data-delay="0" data-close-others="false">Productos <i class="fa fa-angle-down"></i></a>
                          <ul class="dropdown-menu">
                              <li><a href="termoplasticas.php">Válvulas termoplasticas</a></li>
                              <li><a href="metalicas.php">Válvulas metalicas</a></li>
              <li><a href="automatizacion.php">Automatización de válvulas</a></li>
              <li><a href="productosespeciales.php">Productos especiales</a></li>
              <li class="dropdown-submenu">

              </li>
                          </ul>
                      </li>
                      <li><a href="restauracion.php">Servicios</a></li>

          </li>
                      <li><a href="contact.php">Contacto</a></li>
                  </ul>
              </div>
          </div>
      </div>
</header>
