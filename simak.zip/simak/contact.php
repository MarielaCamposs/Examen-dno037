<!DOCTYPE html>
	<html lang="es">
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Simak</title>
	<link rel="icon" type="image/png" href="img/icono.png" />
	<!-- Search Engine -->
	<meta name="description" content="Somos una empresa especializada en productos para la conducción y control de fluidos, dentro de las áreas industriales, químicas, mineras y sanitarias. Poseemos área de ventas como de servicios de reparación.">
	<!-- Schema.org for Google -->
	<meta itemprop="name" content="Simak">
	<meta itemprop="description" content="Somos una empresa especializada en productos para la conducción y control de fluidos, dentro de las áreas industriales, químicas, mineras y sanitarias. Poseemos área de ventas como de servicios de reparación">
	<!-- Twitter -->
	<meta name="twitter:card" content="summary">
	<meta name="twitter:title" content="Simak">
	<meta name="twitter:description" content="Somos una empresa especializada en productos para la conducción y control de fluidos, dentro de las áreas industriales, químicas, mineras y sanitarias. Poseemos área de ventas como de servicios de reparación.">
	<!-- Open Graph general (Facebook, Pinterest & Google+) -->
	<meta name="og:title" content="Simak">
	<meta name="og:description" content="Somos una empresa especializada en productos para la conducción y control de fluidos, dentro de las áreas industriales, químicas, mineras y sanitarias. Poseemos área de ventas como de servicios de reparación">
	<meta name="og:image" content="www.simak.cl/logo.jpg">
	<meta name="og:url" content="www.simak.cl">
	<meta name="og:site_name" content="Simak limitada">
	<meta name="og:type" content="website">

<!-- css -->
<link href="css/bootstrap.min.css" rel="stylesheet" />
<link href="css/cubeportfolio.min.css" rel="stylesheet" />
<link href="css/style.css" rel="stylesheet" />

<!-- js -->
			   	<script src="js/jquery.min.js"></script>
					<script src="js/modernizr.custom.js"></script>
					<script src="js/jquery.easing.1.3.js"></script>
					<script src="js/bootstrap.min.js"></script>
					<script src="js/jquery.appear.js"></script>
					<script src="js/stellar.js"></script>
					<script src="js/classie.js"></script>
					<script src="js/uisearch.js"></script>
					<script src="js/jquery.cubeportfolio.min.js"></script>
					<script src="js/google-code-prettify/prettify.js"></script>
					<script src="js/animate.js"></script>
					<script src="js/custom.js"></script>


<!-- Theme skin -->
<link id="t-colors" href="skins/default.css" rel="stylesheet" />

	<!-- boxed bg -->
	<link id="bodybg" href="bodybg/bg1.css" rel="stylesheet" type="text/css" />

<!-- ============== -->

</head>

<body>

<div id="wrapper">
	<!-- start header -->
	<header>
				 <?php include('header.php');?>
	</header>

	<section id="content">
	<article class="container">
	     <div class="row">
	      <div class="col-lg-11">
        <img src="img/contacto.jpg" alt="Válvulas" width="600px" align="right"
		 		</div>
				<div class="col-lg-3">
					   <h3>Contacto</h3>
	  <form name="contactform" method="post" action="enviado.php">
	  <table width="450px">
	  <tr>
	  <td valign="top">
	  <label for="first_name">Nombre </label>
	  </td>
	  <td valign="top">
	  <input  type="text" name="first_name" maxlength="50" size="30">
	  </td>
	  </tr>
	  <tr>
	  <td valign="top">
	  <label for="last_name">Apellido </label>
	  </td>
	  <td valign="top">
	  <input  type="text" name="last_name" maxlength="50" size="30">
	  </td>
	  </tr>
	  <tr>
	  <td valign="top">
	  <label for="email">Email </label>
	  </td>
	  <td valign="top">
	  <input  type="text" name="email" maxlength="80" size="30">
	  </td>
	  </tr>
	  <tr>
	  <td valign="top">
	  <label for="telephone">Telefono</label>
	  </td>
	  <td valign="top">
	  <input  type="text" name="telephone" maxlength="30" size="30">
	  </td>
	  </tr>
	  <tr>
	  <td valign="top">
	  <label for="comments">Commentarios </label>
	  </td>
	  <td valign="top">
	  <textarea  name="comments" maxlength="1000" cols="25" rows="6"></textarea>
	  </td>
	  </tr>
	  <tr>
	  <td colspan="2" style="text-align:center">
	  <input type="submit" value="Enviar">
	  </td>
	  </tr>
	  </table>
	</form>
	</div>
	</div>
</article>
</section>

					</div>
					<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>

					<footer>
						 <?php include('footer.php');?>
					</footer>

					</body>
					</html>
