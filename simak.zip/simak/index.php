<!DOCTYPE html>
	<html lang="es">
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Simak</title>
	<link rel="icon" type="image/png" href="img/icono.png" />
	<!-- Search Engine -->
	<meta name="description" content="Somos una empresa especializada en productos para la conducción y control de fluidos, dentro de las áreas industriales, químicas, mineras y sanitarias. Poseemos área de ventas como de servicios de reparación.">
	<!-- Schema.org for Google -->
	<meta itemprop="name" content="Simak">
	<meta itemprop="description" content="Somos una empresa especializada en productos para la conducción y control de fluidos, dentro de las áreas industriales, químicas, mineras y sanitarias. Poseemos área de ventas como de servicios de reparación">
	<!-- Twitter -->
	<meta name="twitter:card" content="summary">
	<meta name="twitter:title" content="Simak">
	<meta name="twitter:description" content="Somos una empresa especializada en productos para la conducción y control de fluidos, dentro de las áreas industriales, químicas, mineras y sanitarias. Poseemos área de ventas como de servicios de reparación.">
	<!-- Open Graph general (Facebook, Pinterest & Google+) -->
	<meta name="og:title" content="Simak">
	<meta name="og:description" content="Somos una empresa especializada en productos para la conducción y control de fluidos, dentro de las áreas industriales, químicas, mineras y sanitarias. Poseemos área de ventas como de servicios de reparación">
	<meta name="og:image" content="www.simak.cl/logo.jpg">
	<meta name="og:url" content="www.simak.cl">
	<meta name="og:site_name" content="Simak limitada">
	<meta name="og:type" content="website">
<!-- css -->
<link href="css/bootstrap.min.css" rel="stylesheet" />
<link href="plugins/flexslider/flexslider.css" rel="stylesheet" media="screen" />
<link href="css/cubeportfolio.min.css" rel="stylesheet" />
<link href="css/style.css" rel="stylesheet" />
<!-- js -->
<script src="js/jquery.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="plugins/flexslider/jquery.flexslider-min.js"></script>
<script src="plugins/flexslider/flexslider.config.js"></script>
<script src="js/jquery.appear.js"></script>
<script src="js/stellar.js"></script>
<script src="js/classie.js"></script>
<script src="js/uisearch.js"></script>
<script src="js/jquery.cubeportfolio.min.js"></script>
<script src="js/google-code-prettify/prettify.js"></script>
<script src="js/animate.js"></script>
<script src="js/custom.js"></script>


<!-- Theme skin -->
<link id="t-colors" href="skins/default.css" rel="stylesheet" />

	<!-- boxed bg -->
	<link id="bodybg" href="bodybg/bg1.css" rel="stylesheet" type="text/css" />

<!-- ===================================== -->

</head>
<body>

<div id="wrapper">
	<!-- start header -->
 <?php include('header.php');?>
	<!-- end header -->
	<section id="featured" class="bg">
	<!-- start slider -->


	<!-- 3 fotos inicio -->
	<div class="container">
		<div class="row">
			<div class="col-lg-12""col-md-12""col-sm-12">
	<!-- Slider -->
        <div id="main-slider" class="main-slider flexslider">
            <ul class="slides">
              <li>
                <img src="img/slides/metalicas.JPG" alt="Valvula mariposa" />
                <div class="flex-caption">
                    <h3>Valvulas Metalicas</h3>
					<p>Válvulas para servicios generales, alta temperatura y presión, fluidos corrosivos, operadas de forma manual o automatizada.</p>
					<a href="metalicas.php" class="btn btn-theme">Mas información </a>
                </div>
              </li>
              <li>
                <img src="img/slides/especiales.jpg" alt="Producto" />
                <div class="flex-caption">
                    <h3>Productos especiales</h3>
					<p>Distintas soluciones de conexiones, tuberías, juntas, entre otras, para servicios generales, corrosivos o abrasivos.</p>
					<a href="especial1.php" class="btn btn-theme" >Mas información</a>
                </div>
              </li>
              <li>
                <img src="img/slides/reparacion.jpg" alt="Antes y despues, reparación" />
                <div class="flex-caption">
                    <h3>Servicios</h3>
					<p>Recuperación y mantención de válvulas y equipos industriales.</p>
					<a href="restauracion.php" class="btn btn-theme">Mas información</a>
                </div>
              </li>
            </ul>
        </div>
	<!-- termina 3 fotos inicio -->
			</div>
		</div>
	</div>

	<!-- nuestra empresa -->
<hr>
	<section id="content">
		<div class= "container">
			<div class="row">

					<img src="img/logoblanco.png" alt="Logo Simak" width="1150px"/>
		<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="text-center">
					<h2>Nuestra Empresa</h2>
					<p>Simak fue creada con el objetivo de entregar a sus clientes productos para conducción y control de fluidos garantizados en cuanto a su calidad y disponibilidad en el tiempo. Para ellos contamoscon los conocimientos y el respaldo que nos permiten asesorar en la selección del producto, asistiren la instalación y mantener los productos en el tiempo.</p>
				</div>
			</div>
		</div>
		</div>

		<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="row">
					<div class="col-sm-3 col-md-3 col-lg-4">
						<div class="box">
							<div class="aligncenter">
								<div class="icon">
								<img src="img/mision.jpg" alt="Valvula mariposa" width="300px"/>
								</div>
								<h4><b>Misión</b></h4>
								<p>Somos una empresa constituida por profesionales con gran experiencia y comprometidos con sus funciones. Buscamos satisfacer integralmente las necesidades de nuestros clientes en cuanto al suministro y servicio de productos para la conducción y control de fluidos. Con esto lograremos una empresa sustentable en el tiempo que nos permita desarrollarnos plenamente como profesionales, nuestro ámbito de trabajo será en las aéreas industriales, químicas, mineras y sanitarias.
</p>
							</div>
						</div>
					</div>
					<div class="col-sm-3 col-md-3 col-lg-4">
						<div class="box">
							<div class="aligncenter">
								<div class="icon">
									<img src="img/vision.jpg" alt="Pieza valvula" width="300px"/>
								</div>
								<h4><b>Visión</b></h4>
								<p>Ser una empresa líder en el mercado en cuanto a suministros y servicios de productos para control y conducción de fluidos.</p>
							</div>
						</div>
					</div>
					<div class="col-sm-3 col-md-3 col-lg-4">
						<div class="box">
							<div class="aligncenter">
								<div class="icon">
									<img src="img/responsabilidad.jpg" alt="Producto especial" width="300px"/>
								</div>
								<h4><b>Responsabilidad coorporativa</b></h4>
									<p>Simak tiene un compromiso con la responsabilidad social. Siempre nos guiamos por los principios de sostenibilidad y equidad en la manera de tratar con la gente y el medio ambiente, siempre buscando las mejores soluciones para cada necesidad, con múltiples alternativas.</p>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
		</div>

	<hr>

		<!-- clients -->
		<div class="container">
				<div class="row">
          <div class="col-lg-12">
            <div class="text-center">
          <h5> Nuestros colaboradores </h5>
								<div class="col-xs-6 aligncenter client">
									<img alt="logo Petrovalco" src="img/clients/petrovalco.jpg"  width="400px"/>
									<p><b> Petrovalco USA </b> (1306 Crystal Hills Dr.  Houston Tx- USA 77077 )<br> <b> Petrovalco SA </b>(Matias Pastor Piedra 111, Oropeza, Villa hermoza, Tabasco - Mexico)<br> </p>
								</div>

								<div class="col-xs-6 aligncenter client">
									<img alt="logo WZ" src="img/clients/wz.PNG"  width="400px"/>
								</div>


				</div>
		</div>

	</section>
   <footer>
      <?php include('footer.php');?>
	 </footer>
</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>

</body>
</html>
