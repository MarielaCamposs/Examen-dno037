<!DOCTYPE html>
	<html lang="es">
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Simak</title>
	<link rel="icon" type="image/png" href="img/icono.png" />
	<!-- Search Engine -->
	<meta name="description" content="Somos una empresa especializada en productos para la conducción y control de fluidos, dentro de las áreas industriales, químicas, mineras y sanitarias. Poseemos área de ventas como de servicios de reparación.">
	<!-- Schema.org for Google -->
	<meta itemprop="name" content="Simak">
	<meta itemprop="description" content="Somos una empresa especializada en productos para la conducción y control de fluidos, dentro de las áreas industriales, químicas, mineras y sanitarias. Poseemos área de ventas como de servicios de reparación">
	<!-- Twitter -->
	<meta name="twitter:card" content="summary">
	<meta name="twitter:title" content="Simak">
	<meta name="twitter:description" content="Somos una empresa especializada en productos para la conducción y control de fluidos, dentro de las áreas industriales, químicas, mineras y sanitarias. Poseemos área de ventas como de servicios de reparación.">
	<!-- Open Graph general (Facebook, Pinterest & Google+) -->
	<meta name="og:title" content="Simak">
	<meta name="og:description" content="Somos una empresa especializada en productos para la conducción y control de fluidos, dentro de las áreas industriales, químicas, mineras y sanitarias. Poseemos área de ventas como de servicios de reparación">
	<meta name="og:image" content="www.simak.cl/logo.jpg">
	<meta name="og:url" content="www.simak.cl">
	<meta name="og:site_name" content="Simak limitada">
	<meta name="og:type" content="website">
<!-- css -->
<link href="css/bootstrap.min.css" rel="stylesheet" />
<link href="css/cubeportfolio.min.css" rel="stylesheet" />
<link href="css/style.css" rel="stylesheet" />
<!-- js -->
<script src="js/jquery.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.appear.js"></script>
<script src="js/stellar.js"></script>
<script src="js/classie.js"></script>
<script src="js/uisearch.js"></script>
<script src="js/jquery.cubeportfolio.min.js"></script>
<script src="js/google-code-prettify/prettify.js"></script>
<script src="js/animate.js"></script>
<script src="js/custom.js"></script>


<!-- Theme skin -->
<link id="t-colors" href="skins/default.css" rel="stylesheet" />

</head>
<body>


<div id="wrapper">
	<!-- start header -->
	<header>
				 <?php include('header.php');?>
	</header>
	<!-- end header -->
	<div class="text-center">
	<h3>Válvulas Termoplásticas</h3>

	<section id="content">
<div class="container">

		<div class="item">
        <div class="col-lg-4">
				  <h4>Válvula de Mariposa</h4>
				  <img src="img/termoplasticas/mariposa.jpg" alt="Válvula de Mariposa" class="img-responsive pull-left" />
				  <div align="justify"> -Eje centrado, PN-10. <br>-Cuerpo fabricado en Polipropileno, PVC o PVDF.  <br>-Disco fabricado en Polipropileno, PVC o PVDF. <br>-Eje de acero inoxidable. <br>-Asiento elastomérico. <br>-Extremos tipo Wafer o Lug. <br>-Operación Manual o automatizada. <br>-Tamaños desde 2” hasta 48” (50mm hasta 1200mm).</div>
				</div>
				</div>

				<div class="item">
						<div class="col-lg-4">
							<h4>Válvula de Bola</h4>
							<img src="img/termoplasticas/bola.jpg" alt="Válvula de Bola" class="img-responsive pull-left" />
							 <div align="justify">-Tipo flotante. <br>-PN-10.  <br>-Cuerpo y bola en Polipropileno, Polipropileno reforzado, PVC y PVDF,   Asientos en PTFE, Sellos en EPDM o Viton. <br>-Operación manual o automatizada. <br>-Tamaños desde 1/2” hasta 6” (15mm a 150mm).</div>
						</div>
						</div>

						<div class="item">
								<div class="col-lg-4">
									<h4>Válvula de Diafragma </h4>
									<img src="img/termoplasticas/diafragma.jpg" alt="Válvula de Diafragma " class="img-responsive pull-left" />
									 <div align="justify"> -PN-10, Paso vertedero. <br>-Cuerpo en Polipropileno, PVC o PVDF. <br>-Diafragma elastoméricos en EPDM, Hypalon, Viton o revestidos en polímeros. <br>-Conexión bridada, o a soldar. <br>-Operación manual o automatizada. <br>-Dimensiones desde 1/2”a 10” (15mm a 250mm). </div>
								</div>
								</div>
      </div>

			<section id="content">
		<div class="container">
								<div class="item">
										<div class="col-lg-4">
											<h4>Válvula de control hidráulica</h4>
											<img src="img/termoplasticas/automatica.jpg" alt="Válvula de control hidráulica" class="img-responsive pull-left" />
											 <div align="justify"> -PN 10 .<br>-Cuerpo fabricado en Polipropileno. <br>-Pilotos en termoplástico  o acero inoxidable. <br>-Diafragma fabricado en caucho natural y otros elastómeros. <br>-Extremos roscado o bridados. <br>-Operación automática. <br>-Funciones On-Off, regulación de presión, regulación de flujo, control de nivel, anticipadora de ondas y alivio entre otras. <br>-Tamaño 11/2” hasta 5” (40mm a 125mm).</div>
										</div>
										</div>

										<div class="item">
												<div class="col-lg-4">
													<h4>Válvula de Retención</h4>
													<img src="img/termoplasticas/retencion.jpg" alt="Válvula de Retención" class="img-responsive pull-left" />
													 <div align="justify">PN-10.  <br>-Cuerpo y disco de cierre en Polipropileno, PVC o PVDF. <br>-Asiento y sellos en EPDM, Hypalon o Viton. <br>-Extremos flangeados o soldables. <br>-Tamaño desde 1/2” a  24” (15mm hasta 600mm).</div>
												</div>
												</div>
								</div>

<br>
<br>
<br>
<p> * Para consultas acerca de otros productos, disponibilidad o precios, comunicarse directamente a nuestro correos o teléfonos</p>
<br>
<br>
<br>
<br>
</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>


<footer>
 <?php include('footer.php');?>
</footer>

</body>
</html>
