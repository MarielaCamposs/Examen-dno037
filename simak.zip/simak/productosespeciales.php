<!DOCTYPE html>
	<html lang="es">
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Simak</title>
	<link rel="icon" type="image/png" href="img/icono.png" />
	<!-- Search Engine -->
	<meta name="description" content="Somos una empresa especializada en productos para la conducción y control de fluidos, dentro de las áreas industriales, químicas, mineras y sanitarias. Poseemos área de ventas como de servicios de reparación.">
	<!-- Schema.org for Google -->
	<meta itemprop="name" content="Simak">
	<meta itemprop="description" content="Somos una empresa especializada en productos para la conducción y control de fluidos, dentro de las áreas industriales, químicas, mineras y sanitarias. Poseemos área de ventas como de servicios de reparación">
	<!-- Twitter -->
	<meta name="twitter:card" content="summary">
	<meta name="twitter:title" content="Simak">
	<meta name="twitter:description" content="Somos una empresa especializada en productos para la conducción y control de fluidos, dentro de las áreas industriales, químicas, mineras y sanitarias. Poseemos área de ventas como de servicios de reparación.">
	<!-- Open Graph general (Facebook, Pinterest & Google+) -->
	<meta name="og:title" content="Simak">
	<meta name="og:description" content="Somos una empresa especializada en productos para la conducción y control de fluidos, dentro de las áreas industriales, químicas, mineras y sanitarias. Poseemos área de ventas como de servicios de reparación">
	<meta name="og:image" content="www.simak.cl/logo.jpg">
	<meta name="og:url" content="www.simak.cl">
	<meta name="og:site_name" content="Simak limitada">
	<meta name="og:type" content="website">
<!-- css -->
<link href="css/bootstrap.min.css" rel="stylesheet" />
<link href="css/cubeportfolio.min.css" rel="stylesheet" />
<link href="css/style.css" rel="stylesheet" />
<!-- js -->
<script src="js/jquery.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.appear.js"></script>
<script src="js/stellar.js"></script>
<script src="js/classie.js"></script>
<script src="js/uisearch.js"></script>
<script src="js/jquery.cubeportfolio.min.js"></script>
<script src="js/google-code-prettify/prettify.js"></script>
<script src="js/animate.js"></script>
<script src="js/custom.js"></script>
<!-- Theme skin -->
<link id="t-colors" href="skins/default.css" rel="stylesheet" />

</head>
<body>


<div id="wrapper">
	<!-- start header -->
	<header>
			 <?php include('header.php');?>
	</header>
	<!-- end header -->

	<div class="text-center">
	<h3>Productos especiales</h3>
	<section id="content">
	<div class="container">

		<div class="item">
				<div class="col-lg-4">
					<h4>Tuberías Flexibles </h4>
					<img src="img/especiales/manguera.jpg" alt="Tuberías Flexibles" class="img-responsive pull-left" />
					<p>Fabricadas en PVC o Poliuretano, para una presión de trabajo hasta 86 Bar.<br> Tamaños desde 50mm hasta 300mm. </p>
				</div>
				</div>

		 <div class="item">
				<div class="col-lg-4">
					<h4>Tuberias, Juntas de expansión, y revestimientos elastoméricos</h4>
					<img src="img/especiales/tuberiasjuntas.jpg" alt="Tuberias" class="img-responsive pull-left" />
					<p> Fabricadas en caucho natural, EPDM, Hypalon o Viton. Tamaños desde 15mm hasta 600mm.</p>
				</div>
				</div>

				<div class="item">
					 <div class="col-lg-4">
						 <h4>Productos termoplásticos y semi elaborados</h4>
						 <img src="img/especiales/termoplasticos.jpg" alt="Productos termoplásticos" class="img-responsive pull-left" />
						 <p> Tuberías, accesorios, planchas, barras, perfiles, varillas fabricadas en PE, PP, PVC, PVDF hasta E-CTFE y PETG</p>
					 </div>
					 </div>
	         </div>
					 <br>
					 <br>
<hr>
    <h4>Plásticos reforzados con fibras (FRP)</h4>
 <p> Fabricación de cañerías,  estanques y piezas especiales en FRP</p>
					<section id="content">
					 <div class="container">

						 <div class="item">
								 <div class="col-lg-6">
									 <h5>Estanques</h5>
									 <img src="img/especiales/estanque.jpg" alt="FRP" class="img-responsive pull-left" />
								 </div>
								 </div>

								 <div class="item">
										 <div class="col-lg-6">
											 <h5>Piezas</h5>
											 <img src="img/especiales/piezas.jpg" alt="FRP" class="img-responsive pull-left" />

											 <p>Tuberias, Bridas, Reducciones, Curvas, Tee, Piezas segun plano </p>
										 </div>
										 </div>

					 	 </div>

						<br>
						<br>
						<br>
						<br>
						<br>
<p>* Para consultas acerca de otros productos, disponibilidad o precios, comunicarse directamente a nuestro correos o teléfonos</p>
					</div>
					<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>

					<footer>
						 <?php include('footer.php');?>
					</footer>

					</body>
					</html>
